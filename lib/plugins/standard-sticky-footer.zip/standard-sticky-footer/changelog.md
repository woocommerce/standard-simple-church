# Changelog

## 1.0 (August 29th, 2012)

* Initial release.